package chapter4;
//while
public class LoopStructure {
    public static void main(String []args){

        int x=10;
//        while(x<20){
//            System.out.println(x);
//            x++;
//            //System.out.println("\n");
//        }

        //do while 结构

//        do{
//
//            System.out.println(x);
//            x++;
//
//        }while(x<20);

        //for结构

        for (;x<20;x++){
            System.out.println(x);
        }


        }
}
