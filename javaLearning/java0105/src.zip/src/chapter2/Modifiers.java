package chapter2;

public class Modifiers {
    private boolean myFlag;
    static final double weeks=9.5;
    protected static final int BOXWIDTH=1;
    //不需要其他修饰符
    String version="1.12";
    boolean processOrder(){
        return true;
    }

    public static void main(String []args){


    }
}
