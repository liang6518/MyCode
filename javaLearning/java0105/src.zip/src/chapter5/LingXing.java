package chapter5;
//运用前面变量和for循环，以及if知识，编制一个小程序，程序的功能是在控制台输入由*号组成的菱形。请看以下代码：
public class LingXing {


}
