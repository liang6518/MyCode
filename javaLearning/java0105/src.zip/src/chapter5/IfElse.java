package chapter5;

public class IfElse {
    public static void main(String []args){
        int x=10;
        int y=20;
        if (x==10){
            if (y==20){
                System.out.println("x="+x+"\n"+"y="+y);
            }
        }
    }
}
