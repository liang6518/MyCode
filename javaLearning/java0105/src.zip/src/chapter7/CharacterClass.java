package chapter7;

public class CharacterClass {
    public static void main(String[] args) {

        Character ch = new Character('a');
        System.out.println(ch);

        //也可以自动创建Character对象

        Character ch1 = 'b';
        System.out.println(ch1);

        //转义字符

        System.out.println("欢迎访问\"菜鸟教程\"!");

    }


}
