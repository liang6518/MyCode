package chapter1;

public class QiangZhiLeiZhuan {
    public static void main(String []args){
        int i=123;
        byte b=(byte)i;
        System.out.println(b);
    }
}
