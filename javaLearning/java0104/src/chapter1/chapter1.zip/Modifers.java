package chapter1;
//定义类的public修饰符
public class Modifers {

    private boolean myFlag;

    static final double weeks = 9.5;

    protected final int BOXWIDTH = 42;


    public static void main(String[] args) {

        System.out.println();
    }


}