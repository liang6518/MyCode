package chapter1;

public class JingTai {
    private static double salary;

    public static final String DEPARTMENT="开发人员";
    public static void main(String []args){
        salary=100;
        System.out.println(DEPARTMENT+"salary is:"+'\''+salary+'\'');
    }
}
