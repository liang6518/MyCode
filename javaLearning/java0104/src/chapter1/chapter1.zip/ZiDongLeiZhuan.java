package chapter1;

public class ZiDongLeiZhuan {
    public static void main(String []args){
        char c1='a';
        int i1=c1;
        System.out.println(i1);

        char c2='A';
        int i2=c2+1;
        System.out.println(i2);
    }
}
